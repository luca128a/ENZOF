package com.example.enzof;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.example.enzof.modelo.RegistrosEMG;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.Contract;
import org.jtransforms.fft.DoubleFFT_1D;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Simular2 extends AppCompatActivity {

    //guardado
    private FirebaseDatabase database;
    private DatabaseReference myRef;
    FirebaseAuth auth;

    private static final int SAMPLE_RATE = 200;
    private static final double LOW_CUTOFF_FREQUENCY = 30;
    private static final double HIGH_CUTOFF_FREQUENCY = 99;
    private ArrayList<Double> vector;

    //5. DECLARACIONES PARTE DE LA VENTANAS --------------------------------------------------------
    private static final double windowSizeSeconds = 10;
    boolean Fatiga_promedio = false;
    boolean Fatiga_RMS = false;
    int Ifatiga_promedio = 0;
    int Ifatiga_RMS = 0;
    double referencia2 = 0;
    double referencia3 = 0;
    private double tiempo_fatiga;
    private String presento_fatiga;

    //7. SIMULACION  -------------------------------------------------------------------------------

    private double[] emg;
    private Handler handler;
    private String duracionSegundos;

    //
    private String musculoSeleccionado;
    private float pesoSeleccionado = 0;
    private String FechaDia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simular2);

        //guardado
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("RegistrosEMG");
        auth = FirebaseAuth.getInstance();

        //musculo
        musculoSeleccionado = "Biceps";
        pesoSeleccionado = 5 * 0.5f;

        //FECHA PARA GUARDAR DESPUES -------------------------------------------------------

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", new Locale("es", "AR"));
        sdf.setTimeZone(TimeZone.getTimeZone("America/Argentina/Buenos_Aires"));
        String fechaHoraActual = sdf.format(calendar.getTime());
        FechaDia = fechaHoraActual;

        //LECTURA

        handler = new Handler();
        try {
            AssetManager assetManager = getAssets();
            InputStream inputStream = assetManager.open("Fatiga1.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            String line = reader.readLine();

            // Remover los corchetes [ y ]
            line = line.replace("[", "").replace("]", "");

            // Separar los valores por comas y convertirlos en números double
            String[] values = line.split(",");
            List<Double> emgList = new ArrayList<>();
            for (String value : values) {
                double number = Double.parseDouble(value.trim());
                emgList.add(number);
            }

            // Convertir la lista en un arreglo double[]
            emg = new double[emgList.size()];
            for (int i = 0; i < emgList.size(); i++) {
                emg[i] = emgList.get(i);
            }

            ArrayList<Integer> emglista = new ArrayList<>();
            for (double value : emg) {
                emglista.add((int) value);
            }

            int sfreq = 2000;
            int duracion = emglista.size() / sfreq;
            duracionSegundos = String.valueOf(duracion);

            int cantVentanas = (int) Math.floor(10 * sfreq);


            vector = filtrado(emglista,true,true);

            RegistrosEMG registrosEMG = new RegistrosEMG(FechaDia, musculoSeleccionado, duracionSegundos, pesoSeleccionado, vector, presento_fatiga, tiempo_fatiga);

            if (auth.getCurrentUser() != null) {
                myRef.child(auth.getCurrentUser().getUid()).child(FechaDia).setValue(registrosEMG).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(Simular2.this, "Guardado correctamente", Toast.LENGTH_SHORT).show();

                        Intent i = new Intent(Simular2.this, Historial.class);
                        i.putExtra("FechaSeleccionada", FechaDia);
                        i.putExtra("desdeRegistro", true);
                        startActivity(i);

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Simular2.this, "No se guardó", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public ArrayList<Double> filtrado(ArrayList<Integer> vector, Boolean RMSB, Boolean Periodograma) {

        //1. CONVIERTE EL ARRAYLIST A DOUBLE -------------------------------------------------------

        double[] arreglo = new double[vector.size()];
        for (int i = 0; i < vector.size(); i++) {
            double elemento = vector.get(i).doubleValue();
            arreglo[i] = elemento * 1023 / 5;
        }

        //CALCULO DE LA MEDIA Y SE LE RESTA---------------------------------------------------------
        double mean = calculateMean(arreglo);
        double[] emgWithMeanSubtracted = subtractMean(arreglo, mean);

        //3.FILTRO PASA-BANDAS----------------------------------------------------------------------
        double[] emg_f_pb = applyBandPassFilter(emgWithMeanSubtracted);

        //4.RECTIFICADO ----------------------------------------------------------------------------

        double[] emg_rect = new double[emg_f_pb.length];
        for (int i = 0; i < emg_f_pb.length; i++) {
            emg_rect[i] = Math.abs(emg_f_pb[i]);
        }


        //5. PASA DE DOUBLE A LISTA.

        ArrayList<Integer> emgEnvelopeList = new ArrayList<>();
        for (double value : emg_rect) {
            emgEnvelopeList.add((int) value);
        }

        //6.a. DEPENDE que esta buscando
        List<double[]> windows2 = generateWindows(emg_rect, SAMPLE_RATE, windowSizeSeconds);
        double[] RMS = new double[windows2.size()];
        if (RMSB == true) {

            for (int i = 0; i < windows2.size(); i++) {
                double[] window = windows2.get(i);
                RMS[i] = RMS_f(window, SAMPLE_RATE);
            }

            /// CoMparacion RMS
            for (int k = 0; k < 3; k++) {
                referencia3 += RMS[k];
            }
            referencia3 = referencia3 / 3;
            referencia3 = 13 * referencia3 / 10;
            int consecutivo3 = 0;
            for (int j = 0; j < RMS.length; j++) {
                if (RMS[j] >= referencia3 && j > 3) {
                    consecutivo3 += 1;
                    if (consecutivo3 == 3) {
                        Fatiga_RMS = true;
                        Ifatiga_RMS = j;
                        break;
                    }
                } else {
                    consecutivo3 = 0;
                }
            }

        } else if (Periodograma == true) {

            List<double[]> windows = generateWindows(emg_f_pb, SAMPLE_RATE, windowSizeSeconds);

            double[] MEAN_FFT = new double[windows.size()];
            for (int i = 0; i < windows.size(); i++) {
                double[] window = windows.get(i);
                double[] Caracteristicas = periodograma(window, SAMPLE_RATE);
                MEAN_FFT[i] = Caracteristicas[0];

                // Comparacion MEDIA----------------------------------------------------------------
                for (int k = 0; k < 3; k++) {
                    referencia2 += MEAN_FFT[k];
                }
                referencia2 = referencia2 / 3;
                referencia2 = 3 * referencia2 / 10;
                int consecutivo2 = 0;
                for (int j = 0; j < MEAN_FFT.length; j++) {
                    if (MEAN_FFT[j] <= referencia2 && j > 3) {
                        consecutivo2 += 1;
                        if (consecutivo2 == 3) {
                            Fatiga_promedio = true;
                            Ifatiga_promedio = j;
                            break;
                        }
                    } else {
                        consecutivo2 = 0;
                    }
                }
            }
        }

        //PRESENTO FATIGA?

        if (Fatiga_promedio == true && Fatiga_RMS == true){
            presento_fatiga = "Si";
            tiempo_fatiga  = (Ifatiga_promedio + Ifatiga_RMS) * windowSizeSeconds / 2;
        } else if (Fatiga_promedio == false && Fatiga_RMS == false){
            presento_fatiga = "No";
            tiempo_fatiga = 0;
        } else {
            presento_fatiga = "Si";
            if (Fatiga_promedio == true){
                tiempo_fatiga = Ifatiga_promedio * windowSizeSeconds;
            } else{
                tiempo_fatiga = Ifatiga_RMS * windowSizeSeconds;
            }
        }

        Toast.makeText(Simular2.this, "presento_fatiga" + presento_fatiga + tiempo_fatiga, Toast.LENGTH_SHORT).show();

        //5. PASA DE DOUBLE A LISTA.

        ArrayList<Double> RMSlista = new ArrayList<>();
        /*for (double value : RMS) {
            RMSlista.add((int) value);
        }*/
        RMSlista = linearRegression(RMS);

        return RMSlista;
    }

    public static ArrayList<Double> linearRegression(double[] y) {
        int n = y.length;
        double sumX = 0;
        double sumY = 0;
        double sumXY = 0;
        double sumXX = 0;

        for (int i = 0; i < n; i++) {
            sumX += i;
            sumY += y[i];
            sumXY += i * y[i];
            sumXX += i * i;
        }

        double meanX = sumX / n;
        double meanY = sumY / n;

        double slope = (sumXY - n * meanX * meanY) / (sumXX - n * meanX * meanX);
        double intercept = meanY - slope * meanX;

        double yo = intercept;
        double yf = slope * (n - 1) + intercept;


        if (yo > yf){
            yf = yf / yo;
            yo =1.0;
        } else {
            yo = yo / yf;
            yf = 1;
        }


        ArrayList<Double> regressionResult = new ArrayList<>();
        // Punto inicial
        regressionResult.add(yo); // y = intercept (convertido a int)

        // Punto final
        regressionResult.add(yf); // y = slope * (n - 1) + intercept (convertido a int)

        return regressionResult;
    }

    //----------------------------------------------------------------------------------------------
    //GENERADOR DE VENTANAS-------------------------------------------------------------------------

    public List<double[]> generateWindows(double[] signal, double samplingFrequency, double windowSize) {
        int windowLength = (int) Math.round(windowSize * samplingFrequency);
        int signalLength = signal.length;
        int numWindows = (int) Math.ceil(signalLength / (double) windowLength);

        List<double[]> windows = new ArrayList<>();

        for (int i = 0; i < numWindows; i++) {
            int start = i * windowLength;
            int end = Math.min(start + windowLength, signalLength);

            double[] window = new double[end - start];
            System.arraycopy(signal, start, window, 0, end - start);

            windows.add(window);
        }
        return windows;
    }




    //----------------------------------------------------------------------------------------------
    //PERIODOGRAMA ---------------------------------------------------------------------------------

    public double[] periodograma(double[] x, int fs ) {

        DoubleFFT_1D fft = new DoubleFFT_1D(fs);
        double[] spectrum = new double[fs];
        fft.realForward(x);

        for (int i = 0; i < fs / 2 + 1; i++) {
            double real = x[2 * i];
            double imag = x[2 * i + 1];
            spectrum[i] = (real * real + imag * imag) / fs;
        }
        double[] frec=new double[spectrum.length];
        for (int i = 0; i < fs / 2 + 1; i++) {
            double frequency = i * (fs / 2.0) / (fs / 2.0 + 1);
            frec[i]=frequency;
        }
        double MNFl;
        double MDFl;
        double aa = 0;
        double bb = 0;
        double bb2 = 0;

        for (int i = 0; i < spectrum.length; i++) {
            aa += frec[i] * spectrum[i];
            bb += spectrum[i];
            if (i != 0) {
                bb2 += spectrum[i];
            }
        }

        MNFl = aa / bb;
        MDFl = 0.5 * bb2;

        return new double[] {MNFl, MDFl};

    }

    //----------------------------------------------------------------------------------------------
    //PERIODOGRAMA ---------------------------------------------------------------------------------

    public double RMS_f(double[] senal, int f) {
        double a = 0.0;
        double rms;

        for (int i = 0; i < senal.length; i++) {
            a += Math.pow(senal[i], 2);
        }
        rms = Math.sqrt(a / (senal.length * (1.0 / f)));

        return rms;
    }


    @Contract(pure = true)
    private double calculateMean(@NonNull double[] signal) {
        double sum = 0.0;
        for (double value : signal) {
            sum += value;
        }
        return sum / signal.length;
    }

    @NonNull
    @Contract(pure = true)
    private double[] subtractMean(@NonNull double[] signal, double mean) {
        double[] result = new double[signal.length];
        for (int i = 0; i < signal.length; i++) {
            result[i] = signal[i] - mean;
        }
        return result;
    }

    @NonNull
    public static double[] applyBandPassFilter(@NonNull double[] signal) {
        int n = signal.length;
        // Perform forward FFT
        DoubleFFT_1D fft = new DoubleFFT_1D(n);
        double[] frequencyDomainSignal = new double[2 * n];
        System.arraycopy(signal, 0, frequencyDomainSignal, 0, n);
        fft.realForwardFull(frequencyDomainSignal);
        // Apply the band-pass filter to the frequency domain signal
        double[] filteredSignal = new double[2 * n];
        int lowIndex = (int) Math.ceil(LOW_CUTOFF_FREQUENCY * n / SAMPLE_RATE);
        int highIndex = (int) Math.floor(HIGH_CUTOFF_FREQUENCY * n / SAMPLE_RATE);
        System.arraycopy(frequencyDomainSignal, 0, filteredSignal, 0, 2 * n);
        for (int i = 0; i < lowIndex; i++) {
            filteredSignal[2 * i] = 0.0;
            filteredSignal[2 * i + 1] = 0.0;
        }
        for (int i = highIndex + 1; i < n; i++) {
            filteredSignal[2 * i] = 0.0;
            filteredSignal[2 * i + 1] = 0.0;
        }
        // Perform inverse FFT
        fft.realInverse(filteredSignal, true);
        // Extract the filtered signal from the complex-valued result
        double[] result = new double[n];
        System.arraycopy(filteredSignal, 0, result, 0, n);
        return result;
    }

    public double[] applyLowPassFilter(double[] input, double samplingFrequency, double cutoffFrequency) {
        int signalLength = input.length;
        double nyquistFrequency = samplingFrequency / 2.0;
        double normalizedCutoff = cutoffFrequency / nyquistFrequency;

        // Perform forward FFT
        DoubleFFT_1D fft = new DoubleFFT_1D(signalLength);
        double[] spectrum = new double[signalLength * 2];
        System.arraycopy(input, 0, spectrum, 0, signalLength);
        fft.realForwardFull(spectrum);

        // Apply low-pass filter in frequency domain
        int cutoffIndex = (int) Math.round(normalizedCutoff * signalLength);
        for (int i = cutoffIndex; i < signalLength; i++) {
            spectrum[i * 2] = 0.0;
            spectrum[i * 2 + 1] = 0.0;
        }

        // Perform inverse FFT
        fft.realInverse(spectrum, true);

        // Get the filtered signal
        double[] output = new double[signalLength];
        System.arraycopy(spectrum, 0, output, 0, signalLength);

        return output;
    }


}