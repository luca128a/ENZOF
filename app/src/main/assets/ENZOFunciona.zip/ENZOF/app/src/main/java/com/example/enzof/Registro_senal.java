package com.example.enzof;


import org.jetbrains.annotations.Contract;
import org.jtransforms.fft.DoubleFFT_1D;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.MediaController;

import com.example.enzof.modelo.RegistrosEMG;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.play.core.integrity.e;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.github.mikephil.charting.data.Entry;

import org.jetbrains.annotations.Contract;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

public class Registro_senal extends AppCompatActivity {

    //1. DECLARACIONES PARAMETROS ------------------------------------------------------------------

    private VideoView videoView;
    private MediaController mediaController;
    private Spinner SpinnerM;
    private Spinner SpinnerD;
    private NumberPicker PickerP;
    private String musculoSeleccionado;
    private String duracionSeleccionada;
    private float pesoSeleccionado = 0;
    private String[] opcionesM = {"Músculo","Bíceps", "Tríceps", "Cuádriceps"};
    private ImageButton BIniciar;
    private ImageButton BSimular;
    private ImageButton BGuia;
    private Switch SwitchG;
    private RelativeLayout layout_video;
    private RelativeLayout layout_grafico;
    private RelativeLayout layout_vacio;
    private int yValue = 0;
    private LineChart mChart;
    private RelativeLayout layout_conectar;
    private RelativeLayout layout_duracion;
    private TextView duracionT;

    //2. DECLARACIONES PARA EL BLUETOOTH -----------------------------------------------------------

    private OutputStream outputStream;
    private InputStream inputStream;
    private StringBuilder dataBuffer = new StringBuilder();
    private BluetoothSocket bluetoothSocket;
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_PERMISSION = 2;
    private BluetoothAdapter bluetoothAdapter;
    private ImageButton BSincronizar;

    //3. DECLARACIONES PARA EL TIEMPO --------------------------------------------------------------

    private long tiempoInicio;
    private long tiempoActual;
    private long tiempoTranscurrido;
    private int duracionmaximaseg;
    private int duracionminimaseg;
    private Boolean paso_tiempomin;

    //4. DECLARACIONES PARA EL PROCESAMIENTO -------------------------------------------------------

    private static final int SAMPLE_RATE = 1000;
    private static final double LOW_CUTOFF_FREQUENCY = 20.0;
    private static final double HIGH_CUTOFF_FREQUENCY = 450.0;

    //5. DECLARACIONES PARTE DE LA VENTANAS --------------------------------------------------------
    private static final double windowSizeSeconds = 0.1;
    boolean Fatiga_promedio = false;
    boolean Fatiga_RMS = false;
    int Ifatiga_promedio = 0;
    int Ifatiga_RMS = 0;
    double referencia2 = 0;
    double referencia3 = 0;
    double[] RMS;


    //6. DECLARACIONES PARA EL GUARDADO ------------------------------------------------------------

    private String FechaDia;
    private ImageButton BGuardar;
    private FirebaseDatabase database;
    private DatabaseReference myRef;
    FirebaseAuth auth;
    private Boolean Save;
    private Boolean Start;
    private ArrayList<Integer> vector;
    private double tiempo_fatiga;
    private String presento_fatiga;

    //GENERADOR DE VENTANAS 2----------------------------------------------------------------------
    private int Cant_ventanas1 = 10 * SAMPLE_RATE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_senal);

        // BOTONES Y SPINNERS  ---------------------------------------------------------------------

        SpinnerM = findViewById(R.id.lista_musculo);
        SpinnerD = findViewById(R.id.lista_duracionmax);
        PickerP = findViewById(R.id.numberpicker);
        BIniciar = findViewById(R.id.btn_inciarr);
        BGuia = findViewById(R.id.btn_guia);
        BSincronizar = findViewById(R.id.btn_conectar);
        SwitchG = findViewById(R.id.switch1);
        final VideoView video = findViewById(R.id.videoView);

        duracionmaximaseg=180;
        duracionminimaseg=60;
        paso_tiempomin=false;

        layout_grafico = findViewById(R.id.layout_grafico);
        layout_video = findViewById(R.id.layout_video);
        layout_vacio = findViewById(R.id.layout_vacio);
        layout_duracion = findViewById(R.id.layout_duracion);
        layout_conectar = findViewById(R.id.layout_conectarbt);
        duracionT = findViewById(R.id.textoD);


        // GRAFICO  --------------------------------------------------------------------------------

        mChart = findViewById(R.id.chart1);
        mChart.setHighlightPerTapEnabled(true);
        mChart.setTouchEnabled(true);
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(true);
        mChart.setDrawGridBackground(false);
        mChart.setPinchZoom(true);
        mChart.setBackgroundColor(Color.WHITE);

        XAxis xl = mChart.getXAxis();
        xl.setTextColor(Color.BLACK);
        xl.setDrawGridLines(true);
        xl.setAvoidFirstLastClipping(true);
        xl.setPosition(XAxis.XAxisPosition.BOTTOM);
        xl.setDrawLabels(false);
        YAxis yl = mChart.getAxisRight();
        yl.setTextColor(Color.WHITE);
        yl.setAxisMaximum(500f);
        yl.setDrawGridLines(true);

        LineData data = new LineData();
        mChart.setData(data);

        // BOTON DETENER----------------------------------------------------------------------------

        Save = true;
        Start = false;
        BGuardar = findViewById(R.id.btn_guardar);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("RegistrosEMG");
        auth = FirebaseAuth.getInstance();
        vector = new ArrayList<Integer>();

        // BOTON SIMULAR----------------------------------------------------------------------------
        BSimular = findViewById(R.id.btn_simular);


        //------------------------------------------------------------------------------------------
        //CONFIGURACIÓN DE LOS SPINNERS-------------------------------------------------------------

        //SPINNER MUSCULO

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcionesM);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerM.setAdapter(adapter);

        //SPINNER DURACION (BORRAR)
        /*
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcionesD);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerD.setAdapter(adapter2);
        */

        //OBTIENE EL MUSCULO SELECCIONADO

        SpinnerM.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    Toast.makeText(getApplicationContext(), "Seleccionaste: " + opcionesM[position], Toast.LENGTH_SHORT).show();
                    musculoSeleccionado = opcionesM[position];
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada
            }
        });


        //CONFIGURACION DEL PESO -------------------------------------------------------------------

        PickerP.setMinValue(0);
        PickerP.setMaxValue(44); // 43 = (22 - 0.5) / 0.5

        String[] displayValues = new String[45];
        float value = 0;
        for (int i = 0; i < 45; i++) {
            displayValues[i] = String.format(Locale.getDefault(), "%.1f kg", value);
            value += 0.5f;
        }
        PickerP.setDisplayedValues(displayValues);

        //------------------------------------------------------------------------------------------
        //BOTON SIMULAR-----------------------------------------------------------------------------




        //------------------------------------------------------------------------------------------
        //BOTON SINCRONIZAR-------------------------------------------------------------------------

        BSincronizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectToBluetooth();
            }
        });

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        //------------------------------------------------------------------------------------------

        //------------------------------------------------------------------------------------------
        //BOTON INICIAR REG-------------------------------------------------------------------------
        
        BIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                layout_conectar.setVisibility(View.GONE);
                layout_duracion.setVisibility(View.VISIBLE);

                tiempoInicio = System.currentTimeMillis();
                Start = true;
                pesoSeleccionado = PickerP.getValue() * 0.5f;

                //VERIFICA LO DE SELECCIONAR-------------------------------------------------------- (BORRAR DURACION)

                if ((opcionesM != null && opcionesM.length > 0 && SpinnerM.getSelectedItemPosition() == 0)) {
                    Toast.makeText(Registro_senal.this, "Seleccione un músculo a medir por favor", Toast.LENGTH_SHORT).show();
                } else if ((pesoSeleccionado == 0)) {
                    Toast.makeText(Registro_senal.this, "Seleccione peso por favor", Toast.LENGTH_SHORT).show();
                } else if ((bluetoothSocket == null || !bluetoothSocket.isConnected())) {
                    Toast.makeText(Registro_senal.this, "Conectese a Bluetooth por favor", Toast.LENGTH_SHORT).show();
                } else {
                    //UNA VEZ QUE LO VERIFICO ----------------------------------------------------------

                    SpinnerM.setEnabled(false);
                    //SpinnerD.setEnabled(false);
                    PickerP.setEnabled(false);

                    //VIDEO O GRAFICO ------------------------------------------------------------------

                    if (SwitchG.isChecked()) {
                        layout_grafico.setVisibility(View.VISIBLE);
                    } else {
                        layout_video.setVisibility(View.VISIBLE);
                        reproducirVideo();
                    }

                    //FECHA PARA GUARDAR DESPUES -------------------------------------------------------

                    Calendar calendar = Calendar.getInstance();
                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", new Locale("es", "AR"));
                    sdf.setTimeZone(TimeZone.getTimeZone("America/Argentina/Buenos_Aires"));
                    String fechaHoraActual = sdf.format(calendar.getTime());
                    FechaDia = fechaHoraActual;
                    Save = false;

                    //EMPIEZA A RECIBIR LOS DATOS-------------------------------------------------------
                    beginListenForData();

                }
            }
        });

        //------------------------------------------------------------------------------------------
        //BOTON GUIA -------------------------------------------------------------------------------
        
        BGuia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Save.equals(false) && Start.equals(true)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Registro_senal.this);
                    builder.setTitle("¿Estás seguro de continuar?");
                    builder.setMessage("No se ha guardado la medición");

                    // Agrega el botón "Sí" al cuadro de diálogo
                    builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(Registro_senal.this, guia.class);
                            intent.putExtra("musculoSeleccionado", musculoSeleccionado);
                            intent.putExtra("desdeRegistro", true);
                            startActivity(intent);
                            dialog.dismiss(); // Cierra el cuadro de diálogo
                        }
                    });

                    // Agrega el botón "No" al cuadro de diálogo
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // Acciones a realizar si el usuario hace clic en "No"
                            // ...
                            dialog.dismiss(); // Cierra el cuadro de diálogo
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else {
                    if ((opcionesM != null && opcionesM.length > 0 && SpinnerM.getSelectedItemPosition() == 0)) {
                        Toast.makeText(Registro_senal.this, "Eliga músculo a medir por favor", Toast.LENGTH_SHORT).show();
                    } else {
                        //Va a guia poniendo la opcion correspondiente
                        Intent intent = new Intent(Registro_senal.this, guia.class);
                        intent.putExtra("musculoSeleccionado", musculoSeleccionado);
                        intent.putExtra("desdeRegistro", true);
                        startActivity(intent);
                    }
                }

            }
        });

        //------------------------------------------------------------------------------------------
        //BOTON GUARDAR-----------------------------------------------------------------------------
        
        BGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (paso_tiempomin == false) {
                    Toast.makeText(Registro_senal.this, "DEBE MEDIR COMO MÍNIMO 60 SEGUNDOS", Toast.LENGTH_SHORT).show();
                } else {

                    //PARA LA CONEXIÓN CON BLUETOOTH
                    stopBluetooth();


                    //GUARDAR O NO
                    AlertDialog.Builder builder = new AlertDialog.Builder(Registro_senal.this);
                    builder.setTitle("Guardar medición");
                    builder.setMessage("¿Desea guardar la medición?");

                    builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            // SE DESEA GUARDAR --------------------------------------------------------
                            // 1. VECTOR FILTRADO ------------------------------------------------------

                            vector = filtrado(vector, Boolean.TRUE, Boolean.TRUE);

                            // 3. CALCULA EL TIEMPO -FINAL ----------------------------------------------

                            tiempoActual = System.currentTimeMillis();
                            tiempoTranscurrido = tiempoActual - tiempoInicio;
                            String duracionSegundos = String.valueOf(tiempoTranscurrido / 1000) + " segundos";

                            // 4. GUARDA EN LA BASE DE DATOS -------------------------------------------

                            RegistrosEMG registrosEMG = new RegistrosEMG(FechaDia, musculoSeleccionado, duracionSegundos, pesoSeleccionado, vector, presento_fatiga, tiempo_fatiga);

                            if (auth.getCurrentUser() != null) {
                                myRef.child(auth.getCurrentUser().getUid()).child(FechaDia).setValue(registrosEMG).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Toast.makeText(Registro_senal.this, "Guardado correctamente", Toast.LENGTH_SHORT).show();
                                        Save = true;

                                        Intent i = new Intent(Registro_senal.this, Historial.class);
                                        i.putExtra("FechaSeleccionada", FechaDia);
                                        i.putExtra("desdeRegistro", true);
                                        startActivity(i);

                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(Registro_senal.this, "No se guardó", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //EN CASO DE QUE NO QUIERE GUARDAR VA AL MENÚ
                            Intent i = new Intent(Registro_senal.this, Menu.class);
                            startActivity(i);
                            dialog.dismiss(); // Cierra el cuadro de diálogo
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });
    }

    //----------------------------------------------------------------------------------------------
    //FUNCION REPRODUCIR VIDEO----------------------------------------------------------------------
    
    private void reproducirVideo() {

        //VIDEO DE UNA
        videoView = findViewById(R.id.videoView);
        videoView.setVisibility(View.VISIBLE);
        mediaController = new MediaController(this);
        mediaController.setAnchorView(videoView);
        videoView.setMediaController(mediaController);
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                // Reinicia el video una vez que haya terminado

                videoView.start();
            }
        });
        int videoResource;
        switch (musculoSeleccionado) {
            case "Bíceps":
                videoResource = R.raw.biceps1;
                break;
            case "Tríceps":
                videoResource = R.raw.triceps1;
                break;
            case "Cuádriceps":
                videoResource = R.raw.cuadriceps1;
                break;
            default:
                // Si no se selecciona un músculo válido, muestra un mensaje de error y detén la reproducción del video
                Toast.makeText(Registro_senal.this, "Músculo no válido", Toast.LENGTH_SHORT).show();
                videoView.stopPlayback();
                return;
        }
        String videoPath = "android.resource://" + getPackageName() + "/" + videoResource;
        videoView.setVideoPath(videoPath);
        videoView.start();
    }

    //----------------------------------------------------------------------------------------------
    //IR AL MENU -----------------------------------------------------------------------------------
    public void MENURS(View view) {
        if (Save.equals(false)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(Registro_senal.this);
            builder.setTitle("¿Estás seguro de continuar?");
            builder.setMessage("No se ha guardado la medición");

            // Agrega el botón "Sí" al cuadro de diálogo
            builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Acciones a realizar si el usuario hace clic en "Sí"
                    Intent i = new Intent(Registro_senal.this, Menu.class);
                    startActivity(i);
                    dialog.dismiss(); // Cierra el cuadro de diálogo
                }
            });

            // Agrega el botón "No" al cuadro de diálogo
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Acciones a realizar si el usuario hace clic en "No"
                    // ...
                    dialog.dismiss(); // Cierra el cuadro de diálogo
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            Intent intent = new Intent(Registro_senal.this, Menu.class);
            startActivity(intent);
        }

    }

    //----------------------------------------------------------------------------------------------
    //MUESTRA DISPOSITIVOS BT ----------------------------------------------------------------------

    private void showBluetoothDeviceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Seleccione dispositivo BT");

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            return;
        }
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        final BluetoothDevice[] devices = pairedDevices.toArray(new BluetoothDevice[0]);

        String[] deviceNames = new String[devices.length];
        for (int i = 0; i < devices.length; i++) {
            deviceNames[i] = devices[i].getName();
        }

        builder.setItems(deviceNames, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item) {
                connectToDevice(devices[item]);
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //----------------------------------------------------------------------------------------------
    //FUNCION DE CONECTAR A BLUETOOTH---------------------------------------------------------------

    private void connectToBluetooth() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.BLUETOOTH}, REQUEST_PERMISSION);
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.BLUETOOTH_ADMIN}, REQUEST_PERMISSION);
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSION);
            return;
        }

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not supported on this device", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            showBluetoothDeviceDialog();
        }

    }

    //----------------------------------------------------------------------------------------------
    // FUNCION CONECTA BT CON EL DISPOSITIVO--------------------------------------------------------

    @SuppressLint("MissingPermission")
    private void connectToDevice(BluetoothDevice device) {
        try {
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
            bluetoothSocket = device.createRfcommSocketToServiceRecord(uuid);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                return;
            }
            bluetoothSocket.connect();
            outputStream = bluetoothSocket.getOutputStream();
            inputStream = bluetoothSocket.getInputStream();
            //beginListenForData(); //ES PARA EMPEZAR A RECIBIR DATA
            Toast.makeText(this, "Connected to " + device.getName(), Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //----------------------------------------------------------------------------------------------
    // FUNCION VERIFICA SI ESTA OK EL BT -----------------------------------------------------------

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                showBluetoothDeviceDialog();
            } else {
                Toast.makeText(this, "Bluetooth activation canceled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //----------------------------------------------------------------------------------------------
    // FUNCION DE PERMISOS BLUETOOTH ---------------------------------------------------------------
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                connectToBluetooth();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //----------------------------------------------------------------------------------------------
    // EMPIEZA LA TRANSMISIÓN DE INFO POR BT -------------------------------------------------------

    //BEGIN LISTEN ORIGINAL------------------------------------------------------------------------
    private void beginListenForData() {

        Thread thread = new Thread(new Runnable() {
            public void run() {
                byte[] buffer = new byte[100];
                int bytes;

                while (true) {
                    try {
                        bytes = inputStream.read(buffer);

                        final String message = new String(buffer, 0, bytes);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dataBuffer.append(message);
                                if (dataBuffer.length() > 1000) {
                                    dataBuffer.delete(0, dataBuffer.length() - 1000);
                                }
                                try {
                                    String[] lines = message.split("\\r?\\n");
                                    for (String line : lines) {
                                        String trimmedLine = line.trim();
                                        if (!trimmedLine.isEmpty()) { // Verificar si la línea no está vacía
                                            int numericValue = Integer.parseInt(trimmedLine);
                                            // Establecer el valor entero en el EditText de tipo número
                                            yValue = yValue+1;
                                            if (yValue%1==0){
                                                //addEntry(numericValue,yValue);
                                                duracionT.setText("Muestras " + vector.size());

                                                vector.add(numericValue);
                                            }
                                            break; // Salir del bucle después de encontrar la primera línea con número
                                        }
                                    }
                                } catch (NumberFormatException e) {
                                }
                            }
                        });
                    } catch (IOException e) {
                        break;
                    }
                }

            }
        });

        thread.start();
    }

    //----------------------------------------------------------------------------------------------
    // AGREGAR INFORMACION EN EL VECTOR  -----------------------------------------------------------

    private void addEntry(int y, int x) {
        LineData data = mChart.getData();

        //Parte tiempo borrar
        tiempoActual = System.currentTimeMillis();
        tiempoTranscurrido = tiempoActual - tiempoInicio;
        long duracionSegundos = tiempoTranscurrido / 1000;  // Duración en segundos


        duracionT.setText(String.valueOf(duracionSegundos) + " segundos." + "Muestras " + vector.size());
        if (duracionSegundos > 60){
            paso_tiempomin=true;
        }

        if (duracionSegundos>duracionmaximaseg){
            stopBluetooth();
            ArrayList<Integer> vector3 = filtrado(vector, Boolean.TRUE, Boolean.TRUE);
            RegistrosEMG registrosEMG = new RegistrosEMG(FechaDia,  musculoSeleccionado, duracionSeleccionada,pesoSeleccionado, vector3, presento_fatiga,tiempo_fatiga);

            if (auth.getCurrentUser() != null) {
                myRef.child(auth.getCurrentUser().getUid()).child(FechaDia).setValue(registrosEMG).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(Registro_senal.this, "Guardado correctamente", Toast.LENGTH_SHORT).show();
                        Save = true;

                        Intent i = new Intent(Registro_senal.this, Historial.class);
                        i.putExtra("FechaSeleccionada", FechaDia);
                        i.putExtra("desdeRegistro", true);
                        startActivity(i);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Registro_senal.this, "No se guardo", Toast.LENGTH_SHORT).show();                        }
                });
            }
            Toast.makeText(Registro_senal.this, "FIN DE LA MEDICION. DURACION MAXIMA ALCANZADA", Toast.LENGTH_SHORT).show();


        }


        if (data != null) {
            LineDataSet set = (LineDataSet) data.getDataSetByIndex(0);

            if (set == null) {
                set = createSet();
                data.addDataSet(set);

            }

           data.addEntry(new Entry(x,y),0);

            mChart.notifyDataSetChanged();
            mChart.setVisibleXRangeMaximum(49);
            mChart.moveViewToX(data.getEntryCount()-50);


        }
    }


    //----------------------------------------------------------------------------------------------
    // CONDICIONES DEL GRAFICO ---------------------------------------------------------------------

    private LineDataSet createSet() {
        LineDataSet set = new LineDataSet(null, "EMG");
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER); // Habilita la curva suavizada (cubic)
        set.setCubicIntensity(0.2f);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setColor(ColorTemplate.getHoloBlue());
        set.setCircleColor(ColorTemplate.getHoloBlue());
        set.setLineWidth(2f);
        set.setCircleSize(1f);
        set.setFillAlpha(255);
        set.setFillColor(ColorTemplate.getHoloBlue());
        set.setHighLightColor(Color.rgb(244,117,177));
        set.setDrawValues(false);
        return set;
    }

    //----------------------------------------------------------------------------------------------
    // FUNCIÓN QUE PARA EL BLUETOOTH ---------------------------------------------------------------
    
    private void stopBluetooth() {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Toast.makeText(this, "Bluetooth stopped", Toast.LENGTH_SHORT).show();
    }

    //----------------------------------------------------------------------------------------------
    // FUNCION FILTRADO ----------------------------------------------------------------------------

    public ArrayList<Integer> filtrado(ArrayList<Integer> vector, Boolean RMSB, Boolean Periodograma) {

        //1. CONVIERTE EL ARRAYLIST A DOUBLE -------------------------------------------------------

        double[] arreglo = new double[vector.size()];
        for (int i = 0; i < vector.size(); i++) {
            double elemento = vector.get(i).doubleValue();
            arreglo[i] = elemento * 1023 / 5;
        }

        //CALCULO DE LA MEDIA Y SE LE RESTA---------------------------------------------------------
        double mean = calculateMean(arreglo);
        double[] emgWithMeanSubtracted = subtractMean(arreglo, mean);

        //3.FILTRO PASA-BANDAS----------------------------------------------------------------------
        double[] emg_f_pb = applyBandPassFilter(emgWithMeanSubtracted);

        //4.RECTIFICADO ----------------------------------------------------------------------------

        double[] emg_rect = new double[emg_f_pb.length];
        for (int i = 0; i < emg_f_pb.length; i++) {
            emg_rect[i] = Math.abs(emg_f_pb[i]);
        }

        //5. PASA DE DOUBLE A LISTA.

        ArrayList<Integer> emgEnvelopeList = new ArrayList<>();
        for (double value : emg_rect) {
            emgEnvelopeList.add((int) value);
        }

        //6.a. DEPENDE que esta buscando
        if (RMSB == true) {
            List<double[]> windows2 = generateWindows(emg_rect, SAMPLE_RATE, windowSizeSeconds);
            //List<double[]> windows2 = generateWindows2(emg_rect, Cant_ventanas2);
            double[] RMS = new double[windows2.size()];
            for (int i = 0; i < windows2.size(); i++) {
                double[] window = windows2.get(i);
                RMS[i] = RMS_f(window, SAMPLE_RATE);
            }

            /// CoMparacion RMS
            for (int k = 0; k < 3; k++) {
                referencia3 += RMS[k];
            }
            referencia3 = referencia3 / 3;
            referencia3 = 13 * referencia3 / 10;
            int consecutivo3 = 0;
            for (int j = 0; j < RMS.length; j++) {
                if (RMS[j] >= referencia3 && j > 3) {
                    consecutivo3 += 1;
                    if (consecutivo3 == 3) {
                        Fatiga_RMS = true;
                        Ifatiga_RMS = j;
                        break;
                    }
                } else {
                    consecutivo3 = 0;
                }
            }

        } else if (Periodograma == true) {

            List<double[]> windows = generateWindows(emg_f_pb, SAMPLE_RATE, windowSizeSeconds);
            //List<double[]> windows = generateWindows2(emg_f_pb, Cant_ventanas2);

            double[] MEAN_FFT = new double[windows.size()];
            double[] MEDIA_FFT = new double[windows.size()];
            for (int i = 0; i < windows.size(); i++) {
                double[] window = windows.get(i);
                double[] Caracteristicas = periodograma(window, SAMPLE_RATE);
                MEAN_FFT[i] = Caracteristicas[0];

                // Comparacion MEDIA----------------------------------------------------------------
                for (int k = 0; k < 3; k++) {
                    referencia2 += MEAN_FFT[k];
                }
                referencia2 = referencia2 / 3;
                referencia2 = 3 * referencia2 / 10;
                int consecutivo2 = 0;
                for (int j = 0; j < MEAN_FFT.length; j++) {
                    if (MEAN_FFT[j] <= referencia2 && j > 3) {
                        consecutivo2 += 1;
                        if (consecutivo2 == 3) {
                            Fatiga_promedio = true;
                            Ifatiga_promedio = j;
                            break;
                        }
                    } else {
                        consecutivo2 = 0;
                    }
                }
            }
        } else {
            //
        }
        //PRESENTO FATIGA?

        if (Fatiga_promedio == true && Fatiga_RMS == true){
            presento_fatiga = "Si";
            tiempo_fatiga  = (Ifatiga_promedio + Ifatiga_RMS) * windowSizeSeconds / 2;
        } else if (Fatiga_promedio == false && Fatiga_RMS == false){
            presento_fatiga = "No";
            tiempo_fatiga = 0;
        } else {
            presento_fatiga = "Es probable";
            if (Fatiga_promedio == true){
                tiempo_fatiga = Ifatiga_promedio * windowSizeSeconds;
            } else{
                tiempo_fatiga = Ifatiga_RMS * windowSizeSeconds;
            }
        }

        return emgEnvelopeList;
    }

    //----------------------------------------------------------------------------------------------
    //GENERADOR DE VENTANAS-------------------------------------------------------------------------

    public List<double[]> generateWindows(double[] signal, double samplingFrequency, double windowSize) {
        int windowLength = (int) Math.round(windowSize * samplingFrequency);
        int signalLength = signal.length;
        int numWindows = (int) Math.ceil(signalLength / (double) windowLength);

        List<double[]> windows = new ArrayList<>();

        for (int i = 0; i < numWindows; i++) {
            int start = i * windowLength;
            int end = Math.min(start + windowLength, signalLength);

            double[] window = new double[end - start];
            System.arraycopy(signal, start, window, 0, end - start);

            windows.add(window);
        }
        return windows;
    }




    //----------------------------------------------------------------------------------------------
    //PERIODOGRAMA ---------------------------------------------------------------------------------

    public double[] periodograma(double[] x, int fs ) {

        DoubleFFT_1D fft = new DoubleFFT_1D(fs);
        double[] spectrum = new double[fs];
        fft.realForward(x);

        for (int i = 0; i < fs / 2 + 1; i++) {
            double real = x[2 * i];
            double imag = x[2 * i + 1];
            spectrum[i] = (real * real + imag * imag) / fs;
        }
        double[] frec=new double[spectrum.length];
        for (int i = 0; i < fs / 2 + 1; i++) {
            double frequency = i * (fs / 2.0) / (fs / 2.0 + 1);
            frec[i]=frequency;
        }
        double MNFl;
        double MDFl;
        double aa = 0;
        double bb = 0;
        double bb2 = 0;

        for (int i = 0; i < spectrum.length; i++) {
            aa += frec[i] * spectrum[i];
            bb += spectrum[i];
            if (i != 0) {
                bb2 += spectrum[i];
            }
        }

        MNFl = aa / bb;
        MDFl = 0.5 * bb2;

        return new double[] {MNFl, MDFl};

    }

    //----------------------------------------------------------------------------------------------
    //PERIODOGRAMA ---------------------------------------------------------------------------------

    public double RMS_f(double[] senal, int f) {
        double a = 0.0;
        double rms;

        for (int i = 0; i < senal.length; i++) {
            a += Math.pow(senal[i], 2);
        }
        rms = Math.sqrt(a / (senal.length * (1.0 / f)));

        return rms;
    }


    @Contract(pure = true)
    private double calculateMean(@NonNull double[] signal) {
        double sum = 0.0;
        for (double value : signal) {
            sum += value;
        }
        return sum / signal.length;
    }

    @NonNull
    @Contract(pure = true)
    private double[] subtractMean(@NonNull double[] signal, double mean) {
        double[] result = new double[signal.length];
        for (int i = 0; i < signal.length; i++) {
            result[i] = signal[i] - mean;
        }
        return result;
    }

    @NonNull
    public static double[] applyBandPassFilter(@NonNull double[] signal) {
        int n = signal.length;
        // Perform forward FFT
        DoubleFFT_1D fft = new DoubleFFT_1D(n);
        double[] frequencyDomainSignal = new double[2 * n];
        System.arraycopy(signal, 0, frequencyDomainSignal, 0, n);
        fft.realForwardFull(frequencyDomainSignal);
        // Apply the band-pass filter to the frequency domain signal
        double[] filteredSignal = new double[2 * n];
        int lowIndex = (int) Math.ceil(LOW_CUTOFF_FREQUENCY * n / SAMPLE_RATE);
        int highIndex = (int) Math.floor(HIGH_CUTOFF_FREQUENCY * n / SAMPLE_RATE);
        System.arraycopy(frequencyDomainSignal, 0, filteredSignal, 0, 2 * n);
        for (int i = 0; i < lowIndex; i++) {
            filteredSignal[2 * i] = 0.0;
            filteredSignal[2 * i + 1] = 0.0;
        }
        for (int i = highIndex + 1; i < n; i++) {
            filteredSignal[2 * i] = 0.0;
            filteredSignal[2 * i + 1] = 0.0;
        }
        // Perform inverse FFT
        fft.realInverse(filteredSignal, true);
        // Extract the filtered signal from the complex-valued result
        double[] result = new double[n];
        System.arraycopy(filteredSignal, 0, result, 0, n);
        return result;
    }

    public double[] applyLowPassFilter(double[] input, double samplingFrequency, double cutoffFrequency) {
        int signalLength = input.length;
        double nyquistFrequency = samplingFrequency / 2.0;
        double normalizedCutoff = cutoffFrequency / nyquistFrequency;

        // Perform forward FFT
        DoubleFFT_1D fft = new DoubleFFT_1D(signalLength);
        double[] spectrum = new double[signalLength * 2];
        System.arraycopy(input, 0, spectrum, 0, signalLength);
        fft.realForwardFull(spectrum);

        // Apply low-pass filter in frequency domain
        int cutoffIndex = (int) Math.round(normalizedCutoff * signalLength);
        for (int i = cutoffIndex; i < signalLength; i++) {
            spectrum[i * 2] = 0.0;
            spectrum[i * 2 + 1] = 0.0;
        }

        // Perform inverse FFT
        fft.realInverse(spectrum, true);

        // Get the filtered signal
        double[] output = new double[signalLength];
        System.arraycopy(spectrum, 0, output, 0, signalLength);

        return output;
    }

    public void Simular(View view){
        Intent i = new Intent(this, Simulacion.class);
        startActivity(i);
    }
}



