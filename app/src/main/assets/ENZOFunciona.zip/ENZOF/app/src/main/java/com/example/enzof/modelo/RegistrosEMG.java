package com.example.enzof.modelo;

import java.util.ArrayList;

public class RegistrosEMG {


    public String getPresento() {
        return presento;
    }

    public void setPresento(String presento) {
        this.presento = presento;
    }

    public Double getTiempof() {
        return tiempof;
    }

    public void setTiempof(Double tiempof) {
        this.tiempof = tiempof;
    }

    public ArrayList getVector() {
        return vector;
    }

    public void setVector(ArrayList vector) {
        this.vector = vector;
    }

    public String getFechadia() {
        return fechadia;
    }

    public void setFechadia(String fechadia) {
        this.fechadia = fechadia;
    }

    public String getMusculo() {
        return musculo;
    }

    public void setMusculo(String musculo) {
        this.musculo = musculo;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public Float getPeso() {
        return peso;
    }

    public void setPeso(Float peso) {
        this.peso = peso;
    }

    public RegistrosEMG(){

    }

    public RegistrosEMG(String fechadia, String musculo, String duracion, Float peso, ArrayList vector, String presento, Double tiempof){
        this.fechadia = fechadia;
        this.musculo = musculo;
        this.duracion = duracion;
        this.peso = peso;
        this.vector = vector;
        this.presento = presento;
        this.tiempof = tiempof;
    }

    private String fechadia;
    private String musculo;
    private String duracion;
    private Float peso;
    private ArrayList vector;
    private String presento;
    private Double tiempof;


}
