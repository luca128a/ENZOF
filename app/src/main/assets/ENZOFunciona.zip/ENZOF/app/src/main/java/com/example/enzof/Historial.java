package com.example.enzof;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import com.github.mikephil.charting.data.Entry;

public class Historial extends AppCompatActivity {

    //DECLARAR

    private Spinner spinnerF;
    private TextView txtmusculo;
    private TextView txtduracion;
    private TextView txtpeso;
    private TextView txtfatigado;
    private TextView txttiempof;
    private LinearLayout layout_datos;
    private LinearLayout layout_datosPDF;

    private boolean borrar;

    //PDF
    private ImageButton BPDF;

    //BORRAR 16HS

    private String FechaSeleccionada;


    //DATABASE

    private FirebaseDatabase database;
    private DatabaseReference myRef;
    FirebaseAuth auth;

    //GRAFICO
    private int yValue = 0;
    private LineChart mChart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        database= FirebaseDatabase.getInstance();
        myRef= database.getReference("RegistrosEMG");
        auth=FirebaseAuth.getInstance();

        spinnerF = findViewById(R.id.lista_fechas);
        txtmusculo = findViewById(R.id.musculo_medido);
        txtduracion = findViewById(R.id.duracion_medida);
        txtpeso = findViewById(R.id.peso_seleccionado);
        txtfatigado = findViewById(R.id.si_no_fatiga);
        txttiempof = findViewById(R.id.tiempo_fatigado);
        layout_datos = findViewById(R.id.layout_datos);
        layout_datosPDF = findViewById(R.id.layout_datosPDF);
        layout_datos.setVisibility(View.GONE);

        //PDF
        BPDF = findViewById(R.id.btn_PDF);

        //CONFIGURACION PARA EL GRAFICO
        // Configuración para el eje Y


        //GRAFICA
        mChart = findViewById(R.id.chart1);
        mChart.setHighlightPerTapEnabled(true);
        mChart.setTouchEnabled(true);
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(true);
        mChart.setDrawGridBackground(false);
        mChart.setPinchZoom(true);
        mChart.setBackgroundColor(Color.WHITE);
        mChart.getDescription().setEnabled(false); // Desactivar descripción
        mChart.getLegend().setEnabled(false); // Desactivar leyenda
        mChart.getXAxis().setEnabled(false); // Desactivar eje X
        mChart.getAxisRight().setEnabled(false); // Desactivar eje Y derecho
        YAxis yAxisLeft = mChart.getAxisLeft();
        yAxisLeft.setEnabled(true);

        //DATA
        LineData data = new LineData();
        mChart.setData(data);

        //FIN DE LO AGREGADO 18HS

        //CONFIGURACION SEGUN SI VIENE DE MENU o DE REGISTRO -------------------------------------------------------------

        Intent intent = getIntent();
        FechaSeleccionada = intent.getStringExtra("FechaSeleccionada");
        boolean desdeRegistro = intent.getBooleanExtra("desdeRegistro", false);

        //OBTIENE FECHAS DE FIREBASE Y LAS AGREGA AL SPINNER ---------------------------------------


        myRef.child(auth.getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<String> fechasList = new ArrayList<>();
                fechasList.add("Seleccione una fecha");

                for (DataSnapshot fechaSnapshot : dataSnapshot.getChildren()) {
                    String fecha = fechaSnapshot.getKey();
                    fechasList.add(fecha);
                }
                ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(Historial.this,
                        android.R.layout.simple_spinner_item, fechasList);
                spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerF.setAdapter(spinnerAdapter);

                if (desdeRegistro) {
                    spinnerF.setSelection(spinnerAdapter.getCount() - 1); // Establecer la última opción
                    spinnerF.setEnabled(false); // Deshabilitar el spinner
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Manejar el error aquí
                Toast.makeText(Historial.this, "Error", Toast.LENGTH_SHORT).show();
            }
        });

       //


        // VE QUE SE SELECCIONO EN EL SPINNER

        spinnerF.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String selectedFecha = adapterView.getItemAtPosition(position).toString();

                if (position != 0){
                    layout_datos.setVisibility(View.VISIBLE);
                    layout_datosPDF.setVisibility(View.GONE);
                } else {
                    layout_datos.setVisibility(View.GONE);
                }

                //RECUPERA EL MUSCULO MEDIDO

                myRef.child(auth.getCurrentUser().getUid()).child(selectedFecha).child("musculo").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String data = dataSnapshot.getValue(String.class);
                        txtmusculo.setText(data);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Historial.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });

                //RECUPERA LA DURACION

                myRef.child(auth.getCurrentUser().getUid()).child(selectedFecha).child("duracion").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String data = dataSnapshot.getValue(String.class);
                        txtduracion.setText(data);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Historial.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });

                //RECUPERA EL PESO SELECCIONADO

                myRef.child(auth.getCurrentUser().getUid()).child(selectedFecha).child("peso").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Float data = dataSnapshot.getValue(Float.class);
                        txtpeso.setText(String.valueOf(data));
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Historial.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });

                //RECUPERA SI SE FATIGA O NO

                myRef.child(auth.getCurrentUser().getUid()).child(selectedFecha).child("presento").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String data = dataSnapshot.getValue(String.class);
                        txtfatigado.setText(data);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Historial.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });


                //RECUPERA TIEMPO
                myRef.child(auth.getCurrentUser().getUid()).child(selectedFecha).child("tiempof").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Double data = dataSnapshot.getValue(Double.class);
                        txttiempof.setText(String.valueOf(data));
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Historial.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });


                //RECUPERA EL VECTOR
                myRef.child(auth.getCurrentUser().getUid()).child(selectedFecha).child("vector").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        ArrayList<Integer> arrayList = new ArrayList<>();
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Integer value = snapshot.getValue(Integer.class);
                            arrayList.add(value);
                        }
                        ArrayList<Entry> entries = new ArrayList<>();
                        for (int i = 0; i < arrayList.size(); i++) {
                            float x = i;  // Coordenada X
                            float y = arrayList.get(i);  // Valor del vector en la posición i
                            entries.add(new Entry(x, y));
                        }
                        LineDataSet set = new LineDataSet(entries, "Señal EMG");  // Reemplaza "Datos" con el nombre deseado para el conjunto de datos
                        LineData lineData = new LineData(set);
                        set.setDrawValues(true); // Habilita la visualización de valores en los puntos
                        set.setDrawCircles(true); // Oculta los círculos
                        set.setLineWidth(2f); // Establecer el ancho de línea deseado (2f en este ejemplo)
                        set.setDrawFilled(true); // Habilitar el relleno de la línea
                        set.setFillAlpha(30); // Establecer la transparencia del relleno (0-255)
                        // Configuración de la línea centrada
                        set.setMode(LineDataSet.Mode.LINEAR); // Establecer el modo LINEAR
                        set.setCubicIntensity(0.2f); // Establecer la intensidad de la curva (0-1)
                        mChart.setData(lineData);
                        mChart.invalidate();

                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Historial.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Manejar el evento cuando no se ha seleccionado nada en el spinner
                layout_datos.setVisibility(View.GONE);

            }
        });


    }


public void IrAMenuH(View view){
        Intent i = new Intent(this, Menu.class);
        startActivity(i);
    }
}